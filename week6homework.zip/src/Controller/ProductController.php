<?php
namespace App\Controller;
use App\Repository\ProductRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Doctrine\ORM\EntityManager;
use Doctrine\Persistence\ManagerRegistry;

class ProductController extends AbstractController
{
    #[Route('/product', name: 'product_list', methods: 'GET')]

    public function index(ProductRepository $productRepository): Response
    {
        $products = $productRepository->findAll();
        return $this->json($products);
    }

    #[Route('/product/{id}', name: 'product_show', methods: 'GET')]
    public function showProduct(ProductRepository $productRepository, $id){
        $products = $productRepository->find($id);
        return $this->json($products);
    }

    #[Route('/product/{id}', name: 'product_update', methods: 'PUT')]
    public function updateProduct(ProductRepository $productRepository, $id){
        $products = $productRepository->update($id);
        return $this->json($products);
    }

    #[Route('/product/{id}', name: 'product_update', methods: 'DELETE')]
    public function deleteProduct(ProductRepository $productRepository, $id){
        $products = $productRepository->remove($id);
        return   $id . "numaralı id ye sahip ürün kaldırıldı";
    }

    #[Route('/product', name: 'product_add', methods: 'POST')]
    public function addUrun(Request $request, ProductRepository $productRepository, ManagerRegistry $managerRegistry): JsonResponse
    {
        $entityManager= $managerRegistry->getManager();
        $data = json_decode($request->getContent(), true);
        $productName = $data['productName'];
        $productDescription = $data['productDescription'];
        $productPrice = $data['productPrice'];
        //$productRecordDate = $date;
//print_r($productRecordDate);exit;
        if (empty($productName) || empty($productDescription) || empty($productPrice)) {
            return new JsonResponse(['status' => 'Zorunlu alanlar girilmelidir.']);
        }
        $productRepository->addProduct($productName, $productDescription, $productPrice, $entityManager);
        return new JsonResponse(['status' => 'ürün eklendi']);
    }
}
