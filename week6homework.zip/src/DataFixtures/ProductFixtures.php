<?php

namespace App\DataFixtures;

use App\Entity\Product;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;
use Faker\Factory;

class ProductFixtures extends Fixture
{
    public function load(ObjectManager $manager): void
    {
         //$product = new Product();
         //$manager->persist($product);

        $faker = Factory::create();

        for ($i = 0; $i < 10; $i++) {
            $product = new Product();
            $product->setProductName($faker->firstName);
            $product->setProductDescription($faker->lastName);
            $product->setProductPrice($faker->randomNumber(2));
            $product->setProductRecordDate($faker->dateTime());
           $manager->persist($product);
        }

        $manager->flush();
    }
}
